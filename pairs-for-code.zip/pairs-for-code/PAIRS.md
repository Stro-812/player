# Раздел «Пары»: рисунки, переносы, положение

Рисунки в img/ уже обработаны: коралловая линия #E43941 на прозрачном фоне, поля обрезаны,
линии утолщены где нужно, у ch31 края тоннеля растушёваны. Трассировать в SVG не нужно.
Переведи их в WebP с прозрачностью (качество ~85) и положи в assets/img/pairs/.

Порядок пар на сайте — сверху вниз по таблице. Символ ⏎ — ручной перенос строки во втором слове
(в HTML — <br> или \n с white-space: pre-line). Без ручных переносов браузер переносит длинные слова
в разных местах на разной ширине, и рисунок уезжает относительно текста.

L, W, H — положение рисунка в em от размера слов пары: left, width, min-height обёртки.

| Глава | Верхнее слово  | Нижнее слово (с переносами)       | Файл | L      | W      | H      | Слушать: эпизод, время |
|-------|----------------|-----------------------------------|------|--------|--------|--------|------------------------|
| 6     | Тренер         | глубокий колодец                  | ch06 | 6em    | 3.7em  | 3em    | 3, 00:00:20 (t=20)     |
| 8     | Ящерицы        | сила воли                         | ch08 | 3.2em  | 6.4em  | 4.3em  | 3, 00:21:10 (t=1270)   |
| 12    | О полумарафоне | кредите на⏎неотложные нужды       | ch12 | 6.9em  | 2.9em  | 2.7em  | 4, 00:53:27 (t=3207)   |
| 7     | Техника бега   | плотнейшая⏎упаковка шаров         | ch07 | 5.5em  | 4.3em  | 2.3em  | 3, 00:08:58 (t=538)    |
| 27    | Медленный бег  | капилляры                         | ch27 | 5.05em | 4.2em  | 4.45em | 7, 00:13:11 (t=791)    |
| 15    | Кортизол       | ракетный двигатель                | ch15 | 6.85em | 2.87em | 3.8em  | 5, 00:15:03 (t=903)    |
| 31    | Интервалы      | урановые⏎рудники                  | ch31 | 3.55em | 6.1em  | 4.1em  | 7, 01:12:27 (t=4347)   |
| 40    | Письма         | калоши                            | ch40 | 2.45em | 6.1em  | 4.3em  | 10, 00:00:00 (t=0)     |
| 45    | Вундеркинды    | счастье                           | ch45 | 4.55em | 2.03em | 4.1em  | 11, 01:00:32 (t=3632)  |
| 32    | Макароны       | соглашение⏎о разделе⏎имущества    | ch32 | 3.95em | 5.7em  | 4.2em  | 8, 00:00:00 (t=0)      |

## Разметка одной пары

    <div class="pair-wrap" style="--l: 3.2em; --w: 6.4em; --h: 4.3em">
      <img class="pair-art" src="assets/img/pairs/ch08.webp" alt="" aria-hidden="true">
      <h3 class="pair-words">
        <span class="pair-word">Ящерицы</span>
        <span class="pair-and">и</span>
        <span class="pair-word">сила воли</span>
      </h3>
    </div>

## Стили

    .pair-wrap { position: relative; display: flex; align-items: center;
                 font-size: clamp(56px, 7.5vw, 124px); min-height: var(--h); }
    .pair-art  { position: absolute; left: var(--l); top: 50%; transform: translateY(-50%);
                 width: var(--w); height: auto; z-index: 0; pointer-events: none; }
    .pair-words{ position: relative; z-index: 1; margin: 0; font-family: var(--display);
                 font-weight: 800; text-transform: uppercase; line-height: 0.86; }
    .pair-word { display: block; white-space: pre-line; font-size: 1em; }
    .pair-and  { display: block; margin: 10px 0 8px; font-size: clamp(30px, 3.2vw, 52px);
                 font-weight: 700; text-transform: none; color: var(--coral); }
    @media (max-width: 760px) {
      .pair-wrap { min-height: 60vw; }
      .pair-art  { left: auto; right: -4vw; width: auto; height: auto;
                   max-width: 78vw; max-height: 60vw; }
    }

Перекрытие подобрано по реальной ширине слов в шрифте Sofia Sans Extra Condensed 800:
конец самой длинной строки заходит на край рисунка примерно на 0,4 em. Если поменяешь шрифт,
вес или размер слов — значения L нужно пересчитать.

Образец того, как должно выглядеть, — макет на холсте Claude («Пары — новая концепция»).
